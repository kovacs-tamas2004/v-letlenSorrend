//1. feladat
let napok = ["hétfő", "kedd", "szerda", "csütörtök", "péntek", "szombat", "vasárnap"];
console.log(napok);

//2. feladat
let veletlenSzam = Math.round(Math.random() * 6);
veletlenSzam = 2;
console.log(veletlenSzam);

//3. feladat
let napok2 = [];
let masodikElem = napok.splice(2, 1);
napok2.push(masodikElem[0]);
console.log(napok);
console.log(napok2);

//4. feladat
let veletlenSzam2 = Math.round(Math.random() * 5);
veletlenSzam = 5;
console.log(veletlenSzam2);

//5. feladat
let napok3 = [];
let otodikElem = napok.splice(5, 1);
napok2.push(otodikElem[0]);
console.log(napok);
console.log(napok3);

//6. feladat
let veletlenSzam3 = Math.round(Math.random() * 4);
veletlenSzam = 1;
console.log(veletlenSzam3);

//7. feladat
let napok4 = [];
let elsoElem = napok.splice(1, 1);
napok2.push(elsoElem[0]);
console.log(napok);
console.log(napok4);

//8. feladat
let veletlenSzam4 = Math.round(Math.random() * 3);
veletlenSzam = 0;
console.log(veletlenSzam4);

//9. feladat
let napok5 = [];
let nulladikElem = napok.splice(0, 1);
napok2.push(elsoElem[0]);
console.log(napok);
console.log(napok5);

//10. feladat
let veletlenSzam5 = Math.round(Math.random() * 2);
veletlenSzam = 2;
console.log(veletlenSzam5);

//11. feladat
let napok6 = [];
let masodikElem2 = napok.splice(2, 1);
napok2.push(masodikElem2[0]);
console.log(napok);
console.log(napok6);

//12. feladat
let veletlenSzam6 = Math.round(Math.random());
veletlenSzam = 0;
console.log(veletlenSzam6);

//13. feladat
let napok7 = [];
let nulladikElem2 = napok.splice(0, 1);
napok2.push(masodikElem2[0]);
console.log(napok);
console.log(napok7);

//14. feladat
let napok8 =  ["szerda", "vasárnap", "kedd", "hétfő", "szombat", "csütörtök", "péntek"];
napok8.push(napok[napok.length - 1]);
console.log(napok);
console.log(napok8);


/*function legyenVeletlenSorrend(tomb){
    let ujTomb = [];
    let hossz = tomb.length;

    for (let i = 0; i < hossz; i++) {
        let index = Math.floor(Math.random() * tomb.length);
        ujTomb.push(tomb[index]);
        tomb.splice(index, 1);
    }
    return ujTomb;
}

let napok2 = napok.slice();
let ujSorrend = legyenVeletlenSorrend(napok);
console.log(ujSorrend);
console.log(napok2);*/